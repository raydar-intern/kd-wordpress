Thank you for choosing SociallyViral Theme by MyThemeShop. 
If you face any difficulty, feel free to open new ticket 
in our support forums (https://community.mythemeshop.com/),
our support staff will be more than happy to assist you.

Don't forget to check our in dept WordPress tutorials from
here: https://community.mythemeshop.com/tutorials/

Know more about SociallyViral Pro Version here:
https://mythemeshop.com/themes/sociallyviral/

Happy Blogging!

-
MyThemeShop Team

Copyrights
============================================================
SociallyViral WordPress Theme, Copyright 2015 MyThemeShop
SociallyViral is distributed under the terms of the GNU GPL

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see .

SociallyViral WordPress Theme is derived from Underscores WordPress Theme, Copyright 2013 Automattic, Inc.
Underscores WordPress Theme is distributed under the terms of the GNU GPL

SociallyViral WordPress Theme bundles the following third-party resources:

FontAwesome Icons, Copyright 2015. Created by Dave Gandy
License: SIL OFL 1.1
URL: http://scripts.sil.org/OFL

Images used in screenshot from Pexels.com
License: Creative Commons Zero
https://www.pexels.com/photo/food-salad-restaurant-person-5317/
https://www.pexels.com/photo/person-woman-coffee-cup-5186/
https://www.pexels.com/photo/desk-cable-technology-headphones-8506/
https://www.pexels.com/photo/hand-with-oil-pastel-draws-the-heart-6333/
https://www.pexels.com/photo/road-people-street-smartphone-2224/